package com.example.a3.room.dao;

import android.icu.text.Replaceable;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.a3.room.entity.Record;
import com.example.a3.weatherRetrofit.RetrofitInterface;
import static androidx.room.OnConflictStrategy.REPLACE;

import java.util.List;

@Dao
public interface RecordDAO {

    @Query("SELECT * FROM Record")
    LiveData<List<Record>> getAll();

    @Query("SELECT * FROM Record WHERE record_id = :recordId LIMIT 1")
    Record findByID(int recordId);


    @Insert
    long insert(Record record);

    @Delete
    void delete(Record record);

    @Query("DELETE FROM Record WHERE record_id = :recordId")
    void deleteByID(int recordId);

    @Update
    public void updateRecord(Record Record);

    @Query("DELETE FROM Record")
    void deleteAll();

    @Insert
    void insertAll(Record... Record);

}
