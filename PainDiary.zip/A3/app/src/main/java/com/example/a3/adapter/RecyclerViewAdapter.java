package com.example.a3.adapter;

import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.OnConflictStrategy;

import com.example.a3.databinding.RvLayoutBinding;
import com.example.a3.fragment.HomeFragment;
import com.example.a3.room.entity.Record;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private OnItemClickListener mItemClickListener;
    List<Record> records = new ArrayList<>();
    private Date date;
    private String simpleDate;
    private String painLevel;
    private String stepTaken;
    private String email;
    private String Id;
    private String stepGoal;
    private String temp;
    private String humidity;
    private String pressure;



    //adapter is not like fragment and have no getContext() method to get the current fragment,so it needs an interface to transfer the data from fragment to fragment
    //provides the information connection of adapter to the pain record fragment
    public interface OnItemClickListener{
        void onItemClick(View view, int position, Record record);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        mItemClickListener = onItemClickListener;
    }
//    private String mood;


    //will be used in onCreateView of PainRecordFragment
    public void setData(List<Record> records){
        this.records = records;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    //This method creates a new view holder that is constructed with a new View, inflated from a layout
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        RvLayoutBinding binding = RvLayoutBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new ViewHolder(binding);
    }
    // this method binds the view holder created with data that will be displayed
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder viewHolder, int position) {
        Record record = records.get(position); //the index of the records(list) is equals to record
        date = new Date(record.date);
        simpleDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
        viewHolder.binding.tvDate.setText(simpleDate);
        painLevel = Integer.toString(record.intensityLevel);
        viewHolder.binding.tvPainIntensityLevel.setText(painLevel);
        stepTaken = Integer.toString(record.stepTakenPerDay);

        Id = Integer.toString(record.recordId);   //parse int id to string id
        email = record.email;
        stepGoal = Integer.toString(record.stepGoalPerDay);
        temp = record.temp;
        humidity = record.humidity;
        pressure = record.pressure;
        viewHolder.binding.tvEmail.setText(email);
        viewHolder.binding.tvId.setText(Id);
        viewHolder.binding.tvTemp.setText(temp);
        viewHolder.binding.tvPressure.setText(pressure);
        viewHolder.binding.tvHumidity.setText(humidity);
        viewHolder.binding.tvStepGoalPerDay.setText(stepGoal);



        viewHolder.binding.tvStepTakenPerDay.setText(stepTaken);
        viewHolder.binding.tvMood.setText(record.mood);
        viewHolder.binding.tvPainLocation.setText(record.painLocation);
        viewHolder.binding.imageviewDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeFragment.recordViewModel.deleteById(record.recordId);
                Toast.makeText(v.getContext(), "You have deleted an record", Toast.LENGTH_SHORT).show();
                notifyDataSetChanged();
            }
        });

        //select a row of the record
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mItemClickListener.onItemClick(v, position, record);
            }
        });



    }

    @Override
    public int getItemCount() {
        return records.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder{
        private RvLayoutBinding binding;
        public ViewHolder(RvLayoutBinding binding){
            super(binding.getRoot());
            this.binding = binding;

        }

    }
}
