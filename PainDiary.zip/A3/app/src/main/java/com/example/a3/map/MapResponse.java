package com.example.a3.map;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class MapResponse {

    @SerializedName("results")
    public List<ResultsDTO> results;
    @SerializedName("status")
    public String status;


    public static class ResultsDTO {
        @SerializedName("address_components")
        public List<AddressComponentsDTO> addressComponents;
        @SerializedName("formatted_address")
        public String formattedAddress;
        @SerializedName("geometry")
        public GeometryDTO geometry;
        @SerializedName("place_id")
        public String placeId;
        @SerializedName("types")
        public List<String> types;


        public static class GeometryDTO {
            @SerializedName("bounds")
            public BoundsDTO bounds;
            @SerializedName("location")
            public LocationDTO location;
            @SerializedName("location_type")
            public String locationType;
            @SerializedName("viewport")
            public ViewportDTO viewport;


            public static class BoundsDTO {
                @SerializedName("northeast")
                public NortheastDTO northeast;
                @SerializedName("southwest")
                public SouthwestDTO southwest;


                public static class NortheastDTO {
                    @SerializedName("lat")
                    public Double lat;
                    @SerializedName("lng")
                    public Double lng;
                }


                public static class SouthwestDTO {
                    @SerializedName("lat")
                    public Double lat;
                    @SerializedName("lng")
                    public Double lng;
                }
            }

            public static class LocationDTO {
                @SerializedName("lat")
                public Double lat;
                @SerializedName("lng")
                public Double lng;
            }


            public static class ViewportDTO {
                @SerializedName("northeast")
                public NortheastDTO northeast;
                @SerializedName("southwest")
                public SouthwestDTO southwest;


                public static class NortheastDTO {
                    @SerializedName("lat")
                    public Double lat;
                    @SerializedName("lng")
                    public Double lng;
                }


                public static class SouthwestDTO {
                    @SerializedName("lat")
                    public Double lat;
                    @SerializedName("lng")
                    public Double lng;
                }
            }
        }

        public static class AddressComponentsDTO {
            @SerializedName("long_name")
            public String longName;
            @SerializedName("short_name")
            public String shortName;
            @SerializedName("types")
            public List<String> types;
        }
    }
}

