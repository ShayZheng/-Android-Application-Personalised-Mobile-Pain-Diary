package com.example.a3.fragment;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.a3.HomeScreen;
import com.example.a3.MainActivity;
import com.example.a3.R;
import com.example.a3.alarm.Alarm;
import com.example.a3.databinding.PainDataEntryFragmentBinding;
import com.example.a3.room.entity.Record;
import com.example.a3.weatherRetrofit.Main;
import com.google.android.material.slider.Slider;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PainDataEntryFragment extends Fragment{
    private PainDataEntryFragmentBinding binding;
    private Record editRecord;
    private int painLevel;
    private String locationOfPain;
    //hard coded mood as averge by default
    private String mood = "average";
    private String stepGoalPerDay;
    private String stepTakenPerDay;
    public String date;
    //for edit button
    private int Id;
    private String editDate;
    private String editTemp;
    private String editHumidity;
    private String editPressure;
    private String editEmail;
    private int editPainLevel;
    private String editLocation;
    private String editMood;
    private String editStepsTakenPerDay;
    private String editStepsGoalPerDay;
    public PainDataEntryFragment(){}
    // for time picker
    private Date dateForTimePicker;
    private String timePick;
    private int hour;
    private int minute;
    private int day;
    private int month;
    private int year;





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        binding = PainDataEntryFragmentBinding.inflate(inflater,container, false);
        View view = binding.getRoot();

//        mood = "average"; //hard coded mood as averge by default

        // Retrive the level of pain from slider
        binding.slidePainLevel.addOnChangeListener(new Slider.OnChangeListener() {
            @Override
            public void onValueChange(@NonNull Slider slider, float value, boolean fromUser) {
                painLevel = (int)value; //param the value of the slider to int painLevel
            }
        });
        //Retrive locations of the pain from spinner
        //back, neck, head, knees, hips, abdomen, elbows, shoulders, shins, jaw and facial
        List<String> painLocation = new ArrayList<String>();
        painLocation.add("back");
        painLocation.add("neck");
        painLocation.add("head");
        painLocation.add("knees");
        painLocation.add("hips");
        painLocation.add("abdomen");
        painLocation.add("elbows");
        painLocation.add("shoulders");
        painLocation.add("shins");
        painLocation.add("jaw");
        painLocation.add("facial");

        final ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(view.getContext(),android.R.layout.simple_spinner_item, painLocation);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spPainLocation.setAdapter(spinnerAdapter);
        binding.spPainLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String clickLocation = parent.getItemAtPosition(position).toString();
                if (clickLocation != null){
                    locationOfPain = clickLocation;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //for alarm button
        binding.btAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Alarm.class);
                intent.setAction("Alarm");
                PendingIntent pendingIntent = PendingIntent.getService(getActivity(),0,intent,0);
                int type = AlarmManager.RTC_WAKEUP;  //Real time and wake up the cpu/screen
                if ( dateForTimePicker != null ){
                    long triggerTime = dateForTimePicker.getTime();
                    String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(dateForTimePicker);
                    long mMillisecond = 1000 * 60 * 60 * 24; // a day
                    //Register for alarm service
                    AlarmManager alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
                    alarmManager.setInexactRepeating(type, triggerTime, mMillisecond,pendingIntent);
                    Toast.makeText(getContext(), "Alarm set at: " + time, Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(getContext(), "Please pick a time to set alarm", Toast.LENGTH_SHORT).show();
                }


            }
        });
        //for alarm: pick the time
        binding.editTimePick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timePicker(binding.editTimePick);
            }
        });

        //for save button
        binding.btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Check if the steps input is numeric
                stepGoalPerDay = binding.etStepGoalPerDay.getText().toString(); //string easy to validate
                stepTakenPerDay = binding.etStepTakenPerDay.getText().toString(); //string
                date = new Date().toString(); //param the date on run time
                Main main = HomeFragment.mainOfWeather;

                //actions for room databse: viewmodel -> repository -> DAO -> entity
                //database is used for synchronized
                //save data into PainRecordDatabase of Room
                if (TextUtils.isEmpty(stepGoalPerDay)) {
                    binding.etStepGoalPerDay.setError("Step taken should not be empty");
                    return;
                }
                if (TextUtils.isEmpty(stepTakenPerDay)) {
                    binding.etStepTakenPerDay.setError("Step goal should not be empty");
                    return;
                }
                if (!stepTakenPerDay.matches("^[0-9]*$")){
                    binding.etStepTakenPerDay.setError(("Step taken should be numbers"));
                    return;
                }
                if (!stepGoalPerDay.matches("^[0-9]*$")){
                    binding.etStepGoalPerDay.setError(("Step goal should be numbers"));
                    return;
                }


                    Record record = new Record(MainActivity.emailForRoom, painLevel, locationOfPain, mood,  Integer.parseInt(stepTakenPerDay), Integer.parseInt(stepGoalPerDay), date, main.getTemp(), main.getHumidity(), main.getPressure());
                    HomeFragment.recordViewModel.insert(record);

                    Toast.makeText(view.getContext(),
                            "Data saved!      " + "Pain Level: " + painLevel + "," + "Pain Location: " + locationOfPain + "," + "Mood: " + mood + ","
                                    + "Step Goal: " + stepGoalPerDay + "," + "Step taken: " + stepTakenPerDay,
                            Toast.LENGTH_SHORT).show();

            }
        });

        binding.rgMood.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {


                switch (checkedId){
                    case R.id.rgVeryGood:
                        mood = "very good";
                        break;
                    case R.id.rgGood:
                        mood = "good";
                        break;
                    case R.id.rgAverage:
                        mood = "average";
                        break;
                    case R.id.rgLow:
                        mood = "low";
                        break;
                    case R.id.rgVeryLow:
                        mood = "very low";
                        break;

                }
            }
        });
        //get the values of record
        if (getArguments() != null){
            Id = getArguments().getInt("Id");
            editPainLevel = getArguments().getInt("painLevel");
            editLocation = getArguments().getString("location");
            editMood = getArguments().getString("mood");
            editStepsTakenPerDay = String.valueOf(getArguments().getInt("stepsTakenPerDay"));
            editStepsGoalPerDay = String.valueOf(getArguments().getInt("stepsGoalPerDay"));
            editDate = getArguments().getString("date");
            editTemp = getArguments().getString("temperature");
            editHumidity = getArguments().getString("humidity");
            editPressure = getArguments().getString("pressure");
            editEmail = getArguments().getString("email");

            binding.slidePainLevel.setValue(editPainLevel);
            int pos = 0;
            for (int i = 0; i < painLocation.size(); i++){
                if ( editLocation.equals(painLocation.get(i))){
                    pos = i;
                }
            }
            binding.spPainLocation.setSelection(pos);


            int checkedId = 0;
            switch (editMood){
                case "very good":
                    checkedId = R.id.rgVeryGood;
                    break;
                case "good":
                    checkedId = R.id.rgGood;
                    break;
                case "average":
                    checkedId = R.id.rgAverage;
                    break;
                case "low":
                    checkedId = R.id.rgLow;
                    break;
                case "very low":
                    checkedId = R.id.rgVeryLow;
                    break;
//                default:
//                    checkedId = R.id.rgAverage;
//                    Toast.makeText(view.getContext(), "mood set by default average", Toast.LENGTH_SHORT).show();
//                    break;

            }
//            if (TextUtils.isEmpty(stepGoalPerDay)) {
//                binding.etStepGoalPerDay.setError("Step goal should not be empty");
//                return;
//            }
//
//            if (TextUtils.isEmpty(stepTakenPerDay)) {
//                binding.etStepTakenPerDay.setError("Step taken should not be empty");
//                return;
//            }
//
//            if (!stepTakenPerDay.matches("^[0-9]*$")){
//                binding.etStepTakenPerDay.setError(("Step taken should be numbers"));
//                return;
//            }
//            if (!stepGoalPerDay.matches("^[0-9]*$")){
//                binding.etStepGoalPerDay.setError(("Step goal should be numbers"));
//                return;
//            }

            binding.rgMood.check(checkedId);
            binding.etStepTakenPerDay.setText(editStepsTakenPerDay);
//            binding.etStepGoalPerDay.setText(String.valueOf(editStepsTakenPerDay));
//            binding.etStepGoalPerDay.setText(String.valueOf(editStepsGoalPerDay));
            binding.etStepGoalPerDay.setText(editStepsGoalPerDay);
            binding.btEdit.setClickable(true);



        }



        //for edit button
        binding.btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                int stepTaken = 0;
//                int stepGoal = 0;
//                if (stepGoalPerDay ==null || stepTakenPerDay == null){
//                    Toast.makeText(v.getContext(), "Values should be numbers", Toast.LENGTH_SHORT).show();
//                }
//                if (!isNumeric(stepGoalPerDay) || !isNumeric(stepTakenPerDay)  || mood == null) {
//                    Toast.makeText(v.getContext(), "Values should be numbers", Toast.LENGTH_SHORT).show();
//
//                }
//                else {
                binding.btSave.setEnabled(false);
                stepTakenPerDay = binding.etStepTakenPerDay.getText().toString();
                stepGoalPerDay = binding.etStepGoalPerDay.getText().toString();
                if (TextUtils.isEmpty(stepGoalPerDay)) {
                    binding.etStepGoalPerDay.setError("Step goal should not be empty");
                    return;
                }

                if (TextUtils.isEmpty(stepTakenPerDay)) {
                    binding.etStepTakenPerDay.setError("Step taken should not be empty");
                    return;
                }

                if (!stepTakenPerDay.matches("^[0-9]*$")){
                    binding.etStepTakenPerDay.setError(("Step taken should be numbers"));
                    return;
                }
                if (!stepGoalPerDay.matches("^[0-9]*$")){
                    binding.etStepGoalPerDay.setError(("Step goal should be numbers"));
                    return;
                }




//                    stepTaken = Integer.parseInt(stepTakenPerDay);
//                    stepGoal = Integer.parseInt(stepGoalPerDay);
                editRecord = new Record(editEmail, painLevel, locationOfPain, mood, Integer.parseInt(stepTakenPerDay), Integer.parseInt(stepGoalPerDay), editDate, editTemp, editHumidity, editPressure);
                editRecord.setRecordId(Id);
                HomeFragment.recordViewModel.update(editRecord);
                Toast.makeText(v.getContext(), "You have edited an record", Toast.LENGTH_SHORT).show();

//                }
            }
        });

        return view;

    }

    public void timePicker(TextView time){
        Calendar calendar = Calendar.getInstance();
        minute = calendar.get(Calendar.MINUTE);
        hour = calendar.get(Calendar.HOUR);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH);
        year = calendar.get(Calendar.YEAR);

        TimePickerDialog timePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                // for select time
                Calendar time = Calendar.getInstance();
                time.set(year, month, day, hourOfDay ,(minute-2),0);
                //this is a Date
                dateForTimePicker = time.getTime();
                timePick = new SimpleDateFormat("HH:mm:ss").format(dateForTimePicker);
                binding.editTimePick.setText(timePick);

            }
        },hour,minute,true);

        timePicker.show();
    }

    @Override
    public void onDestroyView(){
        super.onDestroyView();
        binding = null;
    }

    //check if it is numeric
    public boolean isNumeric(String str){
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if( !isNum.matches() ){
            return false;
        }
        return true;
    }

}
