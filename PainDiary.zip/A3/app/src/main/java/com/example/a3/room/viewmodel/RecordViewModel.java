package com.example.a3.room.viewmodel;

import android.app.Application;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.a3.room.entity.Record;
import com.example.a3.room.repository.RecordRepository;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class RecordViewModel extends AndroidViewModel {
    private RecordRepository rRepository;
    private LiveData<List<Record>> allRecords;

    public RecordViewModel (Application application) {
        super(application);
        rRepository = new RecordRepository(application);
        allRecords = rRepository.getAllRecords();
    }

    public void Initialize(Application application){
        rRepository = new RecordRepository(application);

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public CompletableFuture<Record> findByIdFuture(final int recordId) {
        return rRepository.findByIdFuture(recordId);
    }

    public void deleteById(final int recordId){
        rRepository.deleteById(recordId);
    }

    public LiveData<List<Record>> getAllRecords() {
        return allRecords;
    }

    public void insert(Record record) {
        rRepository.insert(record);
    }

    public void deleteAll(){
        rRepository.deleteAll();
    }

    public void update(Record record){
        rRepository.updateRecord(record);
    }


}
