package com.example.a3.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a3.R;
import com.example.a3.adapter.RecyclerViewAdapter;
import com.example.a3.databinding.PainRecordFragmentBinding;
import com.example.a3.room.entity.Record;

import java.util.List;

public class PainRecordFragment extends Fragment {
    private RecyclerViewAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private PainRecordFragmentBinding binding;


    public PainRecordFragment() {

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState){
        binding = PainRecordFragmentBinding.inflate(inflater,container, false);
        View view = binding.getRoot();
        //read from database of room

        //Initialized recycler view adapter
        adapter = new RecyclerViewAdapter();

        //creates a line divider between rows and show in vertical
        binding.recyclerView.addItemDecoration(new DividerItemDecoration(this.getContext(), LinearLayoutManager.VERTICAL));
        binding.recyclerView.setAdapter(adapter);
        layoutManager = new LinearLayoutManager(this.getContext());
        binding.recyclerView.setLayoutManager(layoutManager);

        // method define in RecyclerViewAdapter to transfer the data
        adapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position, Record record) {
                Fragment nFragment = new PainDataEntryFragment();
                Bundle bundle = new Bundle();
                bundle.putString("email", record.email);
                bundle.putInt("Id",record.recordId);
                bundle.putString("date",record.date);
                bundle.putInt("painLevel",record.intensityLevel);
                bundle.putString("location",record.painLocation);
                bundle.putString("mood",record.mood);
                bundle.putInt("stepsTakenPerDay",record.stepTakenPerDay);
                bundle.putInt("stepsGoalPerDay",record.stepGoalPerDay);
                bundle.putString("temperature", record.temp);
                bundle.putString("humidity", record.humidity);
                bundle.putString("pressure", record.pressure);
                nFragment.setArguments(bundle);
                FragmentManager fragmentManager = getFragmentManager();
                //replace the current host fragment
                fragmentManager.beginTransaction().replace(R.id.nav_host_fragment, nFragment).commit();

            }
        });
        HomeFragment.recordViewModel.getAllRecords().observe(getViewLifecycleOwner(), new Observer<List<Record>>() {
            @Override
            public void onChanged(List<Record> records) {
                adapter.setData(records);

//for room test
//                Record r = records.get(1);
//                int painLevel = r.intensityLevel;
//                String email = r.email;
//                String date = r.date;
//                String temp = r.temp;
//                String mood = r.mood;
//                //Test
//                binding.records.setText(email + "             " + date + "            " + temp + "            " + mood + "        "+ painLevel);
            }
        });
        return view;
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
