package com.example.a3.weatherRetrofit;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SearchResponse {

    //Retrive the key of weather of response of API from https://openweathermap.org/

    @SerializedName("weather")
    public List<Weather> weather;

    public List<Weather> getWeather() {
        return weather;
    }

    public void setWeather(List<Weather> weather) {
        this.weather = weather;
    }

    @SerializedName("main")
    public Main main;



    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }





}
