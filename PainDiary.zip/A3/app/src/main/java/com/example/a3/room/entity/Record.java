package com.example.a3.room.entity;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Record {
    //10 information need to store:id(PK unique), pain level, location, mood, steps, date, temp, humidity, pressure, email
    @PrimaryKey (autoGenerate = true)
    @ColumnInfo (name = "record_id")
    public int recordId;

    @ColumnInfo(name = "email")
    @NonNull
    public String email;

    @ColumnInfo(name = "intensity_level")
    @NonNull
    public int intensityLevel;

    @ColumnInfo(name = "pain_location")
    @NonNull
    public String painLocation;

    @ColumnInfo(name = "mood")
    @NonNull
    public String mood;

    @ColumnInfo(name = "step_taken_per_day")
    @NonNull
    public int stepTakenPerDay;

    @ColumnInfo(name = "step_goal_per_day")
    @NonNull
    public int stepGoalPerDay;

    @ColumnInfo(name = "date")
    @NonNull
    public String date;

    @ColumnInfo(name = "temperature")
    @NonNull
    public String temp;

    @ColumnInfo(name = "humidity")
    @NonNull
    public String humidity;

    @ColumnInfo(name = "pressure")
    @NonNull
    public String pressure;

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public Record(@NonNull String email, int intensityLevel, @NonNull String painLocation, @NonNull String mood, @NonNull int stepTakenPerDay, @NonNull int stepGoalPerDay, @NonNull String date, @NonNull String temp, @NonNull String humidity, @NonNull String pressure) {
        this.email = email;
        this.intensityLevel = intensityLevel;
        this.painLocation = painLocation;
        this.mood = mood;
        this.stepGoalPerDay = stepGoalPerDay;
        this.stepTakenPerDay = stepTakenPerDay;
        this.date = date;
        this.temp = temp;
        this.humidity = humidity;
        this.pressure = pressure;
    }

}
