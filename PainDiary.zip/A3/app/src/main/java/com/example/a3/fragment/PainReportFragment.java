

package com.example.a3.fragment;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import com.example.a3.R;
import com.example.a3.databinding.PainDataEntryFragmentBinding;
import com.example.a3.databinding.PainReportFragmentBinding;
import com.example.a3.room.entity.Record;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;

import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class PainReportFragment extends Fragment {
    private PainReportFragmentBinding binding;
    private HashMap<String, Integer> locationHashMap;
    private int count = 0;
    public PainReportFragment(){}
    private String todayDate;
    private String dateOfRecord;
    private int day;
    private int month;
    private int year;
    private Date startDate;
    private Date endDate;
    private List<String> weatherList = new ArrayList<>();
    private String weatherData;
    private ArrayList<Entry> painLevel = new ArrayList<>();
    private float painFloatLevel; //for line chart (lie chart needs float data)
    private float temperatureFloat; //for line chart (lie chart needs float data)
    private float humidityFloat; //for line chart (lie chart needs float data)
    private float pressureFloat; //for line chart (lie chart needs float data)
    private float dateFloat; //for line chart (lie chart needs float data)
    private ArrayList<Entry> weatherLineChart = new ArrayList<>();
    private List<Record> allRecords;
    private Date eachDateForAllRecords;
    //for correlation
    private List<Double> listOfPain = new ArrayList<>();
    private List<Double> listOfWeather = new ArrayList<>();




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        binding = PainReportFragmentBinding.inflate(inflater, container,false);
        View view = binding.getRoot();
        PainLocation();

        binding.tvEndDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickDate(binding.tvEndDatePicker, "end date");
            }
        });

        binding.tvDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickDate(binding.tvDatePicker, "start date");

            }
        });


        weatherList.add("temperature");
        weatherList.add("humidity");
        weatherList.add("pressure");

        final ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(view.getContext(),android.R.layout.simple_spinner_item, weatherList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spWeather.setAdapter(spinnerAdapter);
        binding.spWeather.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedWeather = parent.getItemAtPosition(position).toString();
                if ( selectedWeather != null ){
                    weatherData = selectedWeather;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        // Reset the data of line chart;
        binding.btResetWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.tvRValue.setText("");
                binding.tvPValue.setText("");
                binding.painAndWeatherLineChart.clear();
                listOfPain.clear();
                listOfWeather.clear();
                binding.tvDatePicker.setText("");
                binding.tvEndDatePicker.setText("");

            }
        });
        binding.btSetWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                painLevel.clear();
                weatherLineChart.clear();

                //validation for empty input or selection(in case of crash)
                if (binding.tvDatePicker.getText().toString().isEmpty() || binding.tvEndDatePicker.getText().toString().isEmpty() || weatherData.isEmpty()){
                    Toast.makeText(getContext(), "Date and weather should not be empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    allRecords.forEach(record -> {
                        eachDateForAllRecords = new Date(record.date);
                        // validation for the each date for all records between the start date and end date
                        if( eachDateForAllRecords.after(startDate) && eachDateForAllRecords.before(endDate)){
                            long longDate = new Date(record.date).getTime();
                            dateFloat = (float)longDate;
                            painFloatLevel = (float) record.intensityLevel;
                            pressureFloat = Float.parseFloat(record.pressure);
                            temperatureFloat = Float.parseFloat(record.temp);
                            humidityFloat = Float.parseFloat(record.humidity);

                            painLevel.add(new Entry(dateFloat,painFloatLevel));
                            //for correlation
                            listOfPain.add((double) painFloatLevel);

                            switch(weatherData){
                                case "temperature":
                                    weatherLineChart.add(new Entry(dateFloat, temperatureFloat));
                                    //for correlation
                                    listOfWeather.add((double) temperatureFloat);
                                    break;
                                case "humidity":
                                    weatherLineChart.add(new Entry(dateFloat, humidityFloat));
                                    listOfWeather.add((double) humidityFloat);
                                    break;
                                case "pressure":
                                    weatherLineChart.add(new Entry(dateFloat, pressureFloat));
                                    listOfWeather.add((double) pressureFloat);
                                    break;

                            }

                        }
                    });
                    showPainWeatherLieChart(painLevel,weatherLineChart);


                }
//                String temp = startDate.toString() + "         " +endDate.toString() + "        " + weatherData;
//                Toast.makeText(getContext(), temp, Toast.LENGTH_SHORT).show();
            }
        });

        //for correlation test
        binding.btCorrelation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listOfWeather.isEmpty() || listOfPain.isEmpty()){
                    Toast.makeText(getContext(), "Empty data,Please select the pain and weather", Toast.LENGTH_SHORT).show();
                    return;
                }

                double data[][] = new double[listOfPain.size()][2];
                for (int i = 0; i < listOfPain.size(); i++) {
                    data[i][0] = listOfPain.get(i);
                    data[i][1] = listOfWeather.get(i);
                }
                    RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                    PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(matrix);
                    RealMatrix corM = pearsonsCorrelation.getCorrelationMatrix();
                    RealMatrix pM = pearsonsCorrelation.getCorrelationPValues();
                    binding.tvPValue.setText("P value: " + pM.getEntry(0, 1));
                    binding.tvRValue.setText("Correlation: " + "\n"+ corM.getEntry(0,1));


            }
        });

        return view;
    }

    //initialize pain location as key and its counts(0 by default) as relative values
    public void PainLocation(){

        locationHashMap = new HashMap<>();
        locationHashMap.put("back",0);
        locationHashMap.put("neck",0);
        locationHashMap.put("head",0);
        locationHashMap.put("knees",0);
        locationHashMap.put("hips",0);
        locationHashMap.put("abdomen",0);
        locationHashMap.put("elbows",0);
        locationHashMap.put("shoulders",0);
        locationHashMap.put("shins",0);
        locationHashMap.put("jaw",0);
        locationHashMap.put("facial",0);
        List<PieEntry> locationPieEntries = new ArrayList<>();

        //get all records from database and retrive the information in it
        HomeFragment.recordViewModel.getAllRecords().observe(getViewLifecycleOwner(), new Observer<List<Record>>() {

            @Override
            public void onChanged(List<Record> records) {
                // date for second pie donut chart
                ArrayList<Record> todayRecordDate = new ArrayList<>();
                todayDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                allRecords = records;


                // for (Record record: records) -> lambda forEach
                records.forEach( record -> {
                    dateOfRecord = new SimpleDateFormat("yyyy-MM-dd").format(new Date(record.date));
                    if (locationHashMap.containsKey(record.painLocation)){
                        count = locationHashMap.get(record.painLocation);
                        locationHashMap.put(record.painLocation,  count + 1 );
                    }
                    if(dateOfRecord.equals(todayDate)){
                        todayRecordDate.add(record);

                    }
                });

                locationHashMap.forEach((key, value) ->{
                    if (value > 0)
                        locationPieEntries.add(new PieEntry(value ,key));

                });
                PieDataSet locationDataSet = new PieDataSet(locationPieEntries, "Pain Location");
                locationDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
                locationDataSet.setValueTextSize(15);


                PieData locationData = new PieData(locationDataSet);
                PieChart locationPieChart = binding.locationPieChart;
                locationPieChart.getDescription().setText("Click to play");
                locationPieChart.setEntryLabelTextSize(13);
                locationPieChart.setData(locationData);
                locationPieChart.setRotationEnabled(true);
                locationPieChart.setUsePercentValues(true);


                //refresh the pie chart
                locationPieChart.invalidate();

                //Steps taken chart - Second pie donut chart
                List<PieEntry> stepTakenEntries = new ArrayList<>();
                int remainingSteps;
                int todayStepTaken;
                int todayStepGoal;
                // need validation for no record for current day

//                if (todayRecordDate.isEmpty()){
//                    Toast.makeText(, "", Toast.LENGTH_SHORT).show();
//                }

                if (!todayRecordDate.isEmpty()){
                    todayStepTaken = todayRecordDate.get(0).stepTakenPerDay;
                    todayStepGoal = todayRecordDate.get(0).stepGoalPerDay;
                    stepTakenEntries.add(new PieEntry(todayStepTaken,"Steps taken per day"));
                    remainingSteps = 0;
                    if (todayStepGoal - todayStepTaken >= 0)
                        remainingSteps = todayStepGoal - todayStepTaken;
                    stepTakenEntries.add(new PieEntry(remainingSteps, "Remainning steps"));
                    PieDataSet stepsTakenDataSet = new PieDataSet(stepTakenEntries, "Steps");
                    stepsTakenDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
                    stepsTakenDataSet.setValueTextSize(15);

                    PieData stepTakenData = new PieData(stepsTakenDataSet);
                    PieChart stepTakenPieChart = binding.stepTakenPieChart;
                    stepTakenPieChart.getDescription().setText("Click to play");
                    stepTakenPieChart.setNoDataText("No Record Data Available");
                    stepTakenPieChart.setNoDataTextColor(Color.BLACK);

                    stepTakenPieChart.setData(stepTakenData);
                    stepTakenPieChart.setRotationEnabled(true);
                    stepTakenPieChart.setEntryLabelTextSize(13);
                    //refresh the pie chart
                    stepTakenPieChart.invalidate();
                }
                else {
                    Toast.makeText(getContext(), "You have no pain record today", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }


    public void showPainWeatherLieChart(ArrayList<Entry> painLevel, ArrayList<Entry> weatherLineChart){
        LineChart lineChart = binding.painAndWeatherLineChart;
        lineChart.getDescription().setText("Pain and Weather");
        lineChart.getDescription().setTextSize(13);
        //enable touch
        lineChart.setTouchEnabled(true);
        lineChart.setDragDecelerationFrictionCoef(1.0f);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(true);
        lineChart.setDrawGridBackground(false);
        lineChart.setHighlightPerDragEnabled(true);


        lineChart.setBackgroundColor(Color.WHITE);
        lineChart.setViewPortOffsets(0f,0f,0f,0f);

        //legend
        Legend legend = lineChart.getLegend();
        legend.setWordWrapEnabled(true);
        legend.setFormSize(10f);
        legend.setTextSize(12f);
        legend.setTextColor(Color.BLACK);
        legend.setForm(Legend.LegendForm.LINE);
        legend.setFormSize(10f);
        legend.setTextColor(Color.GREEN);



        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextSize(10f);
        xAxis.setTextColor(Color.GREEN);
        xAxis.setDrawAxisLine(false);
        xAxis.setDrawLabels(true);
        xAxis.setGranularity(1.0f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getAxisLabel(float value, AxisBase axis) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                return simpleDateFormat.format(new Date((long) value));
            }
        });



        //two Y axis
        YAxis yAxis = lineChart.getAxisLeft();
        yAxis.setEnabled(true);
        yAxis.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        yAxis.setTextColor(ColorTemplate.getHoloBlue());
        yAxis.setDrawGridLines(true);
        yAxis.setGranularityEnabled(true);
        yAxis.setAxisMaximum(12f);
        yAxis.setAxisMinimum(0f);
        yAxis.setYOffset(0.9f);
        yAxis.setTextColor(ColorTemplate.getHoloBlue());

        YAxis yAxisTwo = lineChart.getAxisRight();
        yAxisTwo.setEnabled(true);
        yAxisTwo.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        yAxisTwo.setTextColor(ColorTemplate.getHoloBlue());
        yAxisTwo.setDrawGridLines(true);
        yAxisTwo.setGranularityEnabled(true);
        yAxisTwo.setYOffset(0.9f);
        yAxisTwo.setTextColor(ColorTemplate.getHoloBlue());


        LineDataSet painLineDataSet = new LineDataSet(painLevel, "pain level");
//        painLineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        painLineDataSet.setLineWidth(1.5f);
        painLineDataSet.setDrawCircles(false);
        painLineDataSet.setDrawValues(false);
        painLineDataSet.setFillAlpha(60);
        painLineDataSet.setColor(ColorTemplate.JOYFUL_COLORS[0]);
        painLineDataSet.setFillColor(ColorTemplate.JOYFUL_COLORS[3]);
        painLineDataSet.setCircleColor(ColorTemplate.JOYFUL_COLORS[1]);
        painLineDataSet.setValueTextColor(ColorTemplate.JOYFUL_COLORS[2]);
        painLineDataSet.setHighLightColor(Color.rgb(244,117, 117));
        painLineDataSet.setDrawCircleHole(false);

        LineDataSet weatherLineDataSet = new LineDataSet(weatherLineChart, "weather data");
        weatherLineDataSet.setAxisDependency(YAxis.AxisDependency.RIGHT);
        weatherLineDataSet.setLineWidth(1.5f);
        weatherLineDataSet.setDrawCircles(false);
        weatherLineDataSet.setDrawValues(false);
        weatherLineDataSet.setFillAlpha(60);
        weatherLineDataSet.setFillColor(ColorTemplate.JOYFUL_COLORS[3]);
        weatherLineDataSet.setCircleColor(ColorTemplate.JOYFUL_COLORS[1]);
        weatherLineDataSet.setValueTextColor(ColorTemplate.JOYFUL_COLORS[2]);
        weatherLineDataSet.setColor(ColorTemplate.JOYFUL_COLORS[4]);
        weatherLineDataSet.setHighLightColor(Color.rgb(244,117, 117));
        weatherLineDataSet.setDrawCircleHole(false);



        ArrayList<ILineDataSet> iLineDataSets = new ArrayList<>();
        iLineDataSets.add(painLineDataSet);
        iLineDataSets.add(weatherLineDataSet);
        LineData lineData = new LineData(iLineDataSets);
        lineData.setValueTextColor(Color.YELLOW);
        lineData.setValueTextSize(9f);



        lineChart.setData(lineData);
//        lineChart.setNoDataText("No Pain and Weather Data Available");
//        lineChart.setNoDataTextColor(Color.BLACK);

        //refresh the line chart
        lineChart.invalidate();







    }

    public void pickDate(TextView textView, String selectDate){
        final Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), AlertDialog.THEME_HOLO_DARK, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //validation or crash
                textView.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
                if (selectDate.equals("start date")){
                    startDate = new Date((year - 1900),month, dayOfMonth);
                }
                else{
                    endDate = new Date((year - 1900),month, dayOfMonth);
                }
            }
        }, year, month, day);

        datePickerDialog.show();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
