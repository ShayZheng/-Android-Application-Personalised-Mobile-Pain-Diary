//Reference: https://blog.csdn.net/lxb00321/article/details/80018844

package com.example.a3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.example.a3.databinding.ActivitySignUpBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUp extends AppCompatActivity {

    private FirebaseAuth auth; //Declare an instance of FirebaseAuth
    private ActivitySignUpBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        auth = FirebaseAuth.getInstance();  //initialise FirebaseAuth instance
        binding.signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //enter the sign up information
                String email = binding.etEmail.getText().toString();
                String pwd = binding.etPassword.getText().toString();
                String confirmPwd = binding.etConfirmPassword.getText().toString();
                if (TextUtils.isEmpty(email)){
                    binding.etEmail.setError("Email should not be empty");
                    return;
                }
                /*
                 * " \w"：equals to '[A-Za-z0-9_]',could be alphabets,numbers and _
                 * "|"  : means "or"
                 * "*" : 0 or multiple times
                 * "+" : 1 or multiple times
                 * "{n,m}" : the length should be n to m(n and m is numbers)
                 * "$" : end by the previous string
                 */

                if (!email.matches("^\\w+((-\\w+)|(\\.\\w+))*@\\w+(\\.\\w{2,3}){1,3}$")){
                    binding.etEmail.setError(("Email format is not correct"));
                    return;
                }

                //need other validation for password
                if (TextUtils.isEmpty(pwd)){
                    binding.etPassword.setError("Password should not be empty");
                    return;
                }

                if (!pwd.matches("^([a-zA-Z0-9]{8,16})*$")){
                    binding.etPassword.setError("Password should only contains alphabets and numbers, the length should be 8-16");
                    return;
                }

                if (!confirmPwd.equals(pwd)){
                    binding.etConfirmPassword.setError("Password is not match");
                    return;
                }

                binding.progressBar.setVisibility(View.VISIBLE);
                auth.createUserWithEmailAndPassword(email,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(SignUp.this, "User successfully created", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        }
                        else{
                            Toast.makeText(SignUp.this, "Fail to create user", Toast.LENGTH_SHORT).show();
                            binding.progressBar.setVisibility(View.GONE);

                        }
                    }
                });
            }
        });
    }
}