package com.example.a3.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.a3.databinding.HomeFragmentBinding;
import com.example.a3.room.viewmodel.RecordViewModel;
import com.example.a3.viewmodel.SharedViewModel;
import com.example.a3.weatherRetrofit.Main;
import com.example.a3.weatherRetrofit.RetrofitClient;
import com.example.a3.weatherRetrofit.RetrofitInterface;
import com.example.a3.weatherRetrofit.SearchResponse;
import com.example.a3.weatherRetrofit.Weather;

import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {
    public static RecordViewModel recordViewModel;  //any class can use this viewmodel including the recyclerview adapter
    private RetrofitInterface retrofitInterface;
    public static List<Weather> listOfWeather;
    public static Main mainOfWeather;
    private static final String UNIT = "metric";
    private static final String APP_ID = "6fa5ea5a07d6bc3d689026830c4d16bb";
    private String keyword = "Huizhou,Cn";
    private SharedViewModel model;
    private HomeFragmentBinding binding;
    private String Temp;
    private String Humidity;
    private String Pressure;
    private String result;


    public HomeFragment() {}

    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //Inflate the View for this fragment
        binding = HomeFragmentBinding.inflate(inflater, container, false);
        View view = binding.getRoot();


        //Use Retrofit to get the weather information
        retrofitInterface = RetrofitClient.getRetrofitService();
        Call<SearchResponse> callAsync = retrofitInterface.searchResponse(keyword, UNIT, APP_ID);
        //makes an async request & invokes callback methods when the response returns

        callAsync.enqueue(new Callback<SearchResponse>() {
            @Override
            public void onResponse(Call<SearchResponse> call, Response<SearchResponse> response) {
                if (response.isSuccessful()) {
                    listOfWeather = response.body().weather;
                    String weather = listOfWeather.get(0).getMain();
                    mainOfWeather = response.body().main;
//                    String temp = mainOfWeather.getTemp();
//                    binding.weather.setText(temp);
//                    Log.i("temp", temp);

                    result = weather;

                    // param the pressure, temp and humidity from the weather API to Pressure, Temp and Humidity
                    Pressure = mainOfWeather.getPressure();
                    Temp = mainOfWeather.getTemp();
                    Humidity = mainOfWeather.getHumidity();
                    Toast.makeText(view.getContext(), "Temp: " + Temp + ", " + "Humidity: " + Humidity + ", " + "Pressure: " + Pressure, Toast.LENGTH_SHORT).show();
                    binding.weather.setText("Weather: " + result);
                    binding.weatherData.setText("Temperature: " + Temp + "\n" + "Humidity: " + Humidity +"\n"+ "Pressure: " + Pressure);
                    String date = new Date().toString();
                    binding.tvDate.setText("Date: " + date);


                }
                else {
                    Log.i("Error", "Response failed");
                }
            }

            @Override
            public void onFailure(Call<SearchResponse> call, Throwable t) {
                Toast.makeText(view.getContext(), t.getMessage(), Toast.LENGTH_SHORT);

            }


        });
        return view;
    }

    //task 4 reclycler view can use this view model to get the information of pain record
    @Override
    public void onStart() {

        super.onStart();
        recordViewModel = new ViewModelProvider(this).get(RecordViewModel.class);
        recordViewModel.Initialize(getActivity().getApplication());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}

