//This is a Login activity
// Reference: https://blog.csdn.net/lxb00321/article/details/80018844  /For register validation
//            https://www.jianshu.com/p/bf18a381b032  /For button
//            https://juejin.cn/post/6844903764365721613 /For Line chart
//            https://firebase.google.com/docs/firestore/quickstart?authuser=0#java_2  // for task 7 firebase store record

package com.example.a3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.example.a3.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth auth; //Declare an instance of FirebaseAuth
    private ActivityMainBinding binding;
    public static String emailForRoom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        auth = FirebaseAuth.getInstance();  //initialise FirebaseAuth instance
        // Remember the user email and password by using sharepreferences
        SharedPreferences sharedPreferences = getSharedPreferences("userinfo",MODE_PRIVATE);

        if (sharedPreferences.getString("rememberUser","").equals("true")){
            binding.ckEmailPwd.setChecked(true);
            binding.email.setText(sharedPreferences.getString("email",""));
            binding.password.setText(sharedPreferences.getString("password",""));
        }

        binding.signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SignUp.class));
            }
        });

        binding.signinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = binding.email.getText().toString();
                String pwd = binding.password.getText().toString();
                if (TextUtils.isEmpty(email)) {
                    binding.email.setError("Email should not be empty");
                    return;
                }

                /*
                 * " \w"：equals to '[A-Za-z0-9_]',could be alphabets,numbers and _
                 * "|"  : means "or"
                 * "*" : 0 or multiple times
                 * "+" : 1 or multiple times
                 * "{n,m}" : the length should be n to m(n and m is numbers)
                 * "$" : end by the previous string
                 */
//                                          "^\\w+((-\\w+)|(\\.\\w+))*@\\w+(\\.\\w{2,3}){1,3}$"
                if (!email.matches("^\\w+((-\\w+)|(\\.\\w+))*@\\w+(\\.\\w{2,3}){1,3}$")){
                    binding.email.setError(("Email format is not correct"));
                    return;
                }

                if (TextUtils.isEmpty(pwd)) {
                    binding.password.setError("Password should not be empty");
                    return;
                }

                if (!pwd.matches("^([a-zA-Z0-9]{8,16})*$")){
                    binding.password.setError("Password should only contains alphabets and numbers, the length should be 8-16");
                    return;
                }

                binding.progressBar.setVisibility(View.VISIBLE);

                // if click checkbox then will remember the user email and password
                if (binding.ckEmailPwd.isChecked()){
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("email", binding.email.getText().toString());
                    editor.putString("password",binding.password.getText().toString());
                    editor.putString("rememberUser","true");
                    editor.commit();
                }
                else{
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("remenberUser","false");
                    editor.commit();
                }

                auth.signInWithEmailAndPassword(email, pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            emailForRoom = email;
                            Toast.makeText(MainActivity.this, "Successfully sign in", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), HomeScreen.class));
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to sign in", Toast.LENGTH_SHORT).show();
                        }
                        binding.progressBar.setVisibility(View.GONE);
                    }
                });

            }
        });


    }

}
