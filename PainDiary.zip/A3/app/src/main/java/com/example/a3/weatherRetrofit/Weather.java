package com.example.a3.weatherRetrofit;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Weather {
    // Retrive the key of main of response of API from https://openweathermap.org/


    @SerializedName("main")
    public String main;

    public String getMain() {
        return main;
    }

    public void setMain(String main) {
        this.main = main;
    }
}
