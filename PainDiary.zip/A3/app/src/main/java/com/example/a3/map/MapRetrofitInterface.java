package com.example.a3.map;

import com.example.a3.weatherRetrofit.SearchResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MapRetrofitInterface {
    @GET("maps/api/geocode/json")
    Call<MapResponse> mapResponse(@Query("address") String add,
                                        @Query("key") String KEY
                                        );
}
