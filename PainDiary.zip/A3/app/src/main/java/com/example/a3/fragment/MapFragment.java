package com.example.a3.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.a3.databinding.MapFragmentBinding;
import com.example.a3.map.MapResponse;
import com.example.a3.map.MapRetrofitClient;
import com.example.a3.map.MapRetrofitInterface;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MapFragment extends Fragment {
    private static final String KEY = "AIzaSyCs7DQ-GaEK5IJE--hwTVv48C6C-FJAyEg";
    private MapRetrofitInterface mapRetrofitInterface;
    private Double lat;
    private Double lng;
    private GoogleMap map;
    private MapFragmentBinding binding;
    private MapView mapview;

    public MapFragment(){}

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        binding = MapFragmentBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        binding.searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String address = binding.etAddress.getText().toString();
                mapRetrofitInterface = MapRetrofitClient.getRetrofitService();
                Call<MapResponse> callAsync = mapRetrofitInterface.mapResponse(address, KEY);
                callAsync.enqueue(new Callback<MapResponse>() {
                    @Override
                    public void onResponse(Call<MapResponse> call, Response<MapResponse> response) {
                        if (response.isSuccessful()){
                            mapview = (MapView) binding.mapView;
                            lng = response.body().results.get(0).geometry.location.lng;
                            lat = response.body().results.get(0).geometry.location.lat;

                            if (mapview != null) {
                                mapview.onCreate(null);
                                mapview.onResume();
                                mapview.getMapAsync(new OnMapReadyCallback() {
                                    @Override
                                    public void onMapReady(@NonNull GoogleMap googleMap) {
                                        map = googleMap;
                                        LatLng latLng = new LatLng(lat, lng);
                                        map.addMarker(new MarkerOptions().position(latLng).title("Home"));
                                        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13f));
                                    }
                                });
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<MapResponse> call, Throwable t) {

                    }
                });
            }
        });
        return view;
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
