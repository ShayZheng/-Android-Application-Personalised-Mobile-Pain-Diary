package com.example.a3.alarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.RequiresApi;

import com.example.a3.MainActivity;
import com.example.a3.R;

public class Alarm extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                NotificationManager notificationManager = (NotificationManager) getSystemService(
                        Context.NOTIFICATION_SERVICE
                );
                notificationManager.createNotificationChannel(new NotificationChannel("Pain diary", "reminder" ,NotificationManager.IMPORTANCE_DEFAULT));
                //main activity is the login page which is the first page for the pain diary
                Intent newIntent = new Intent(getApplication(), MainActivity.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(getApplication(), 0,newIntent,0);
                Notification.Builder builder = new Notification.Builder(getApplication(),"Pain diary"); //should align with channel id

                //set notification visibility
                builder.setVisibility(Notification.VISIBILITY_PUBLIC);
                //set the title
                builder.setContentTitle("Pain diary reminder");
                //set the context
                builder.setContentText("Please enter your data");
                //set the image in status bar(transparent)
                builder.setSmallIcon(R.drawable.ic_good);
                //click to cancel the status bar notification
                builder.setAutoCancel(true);
                //set status bar
                builder.setContentIntent(pendingIntent);

                //build the notification
                Notification painNotification = builder.build();
                notificationManager.notify(1, painNotification);

            }
        }).start();

        return super.onStartCommand(intent, flags, startId);
    }
}


