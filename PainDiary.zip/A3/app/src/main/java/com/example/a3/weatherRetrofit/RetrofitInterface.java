package com.example.a3.weatherRetrofit;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrofitInterface {
    @GET("data/2.5/weather")
    Call<SearchResponse> searchResponse(@Query("q") String keyword,
                                        @Query("units") String UNIT,
                                        @Query("appid") String APP_ID
                                        );
}
