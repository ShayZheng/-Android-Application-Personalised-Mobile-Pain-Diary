package com.example.a3.room.repository;

import android.app.Application;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.lifecycle.LiveData;

import com.example.a3.room.dao.RecordDAO;
import com.example.a3.room.database.PainRecordDatabase;
import com.example.a3.room.entity.Record;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;


public class RecordRepository {
    private Record record;
    private RecordDAO recordDAO;
    private LiveData<List<Record>> allRecords;


    public RecordRepository(Application application){
        PainRecordDatabase db = PainRecordDatabase.getInstance(application);
        recordDAO = db.recordDAO();

    }

    //Room executes this query on a separate thread
    public LiveData<List<Record>>getAllRecords(){
        allRecords = recordDAO.getAll();
        return allRecords;
    }

    public void insert(final Record record){
        PainRecordDatabase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                recordDAO.insert(record);
            }
        });
    }

    public void deleteAll(){
        PainRecordDatabase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                recordDAO.deleteAll();
            }
        });

    }

    public void delete(final Record record){
        PainRecordDatabase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                recordDAO.delete(record);
            }
        });
    }

    public void deleteById(final int recordId){
        PainRecordDatabase.databaseWriteExecutor.execute((new Runnable() {
            @Override
            public void run() {
                recordDAO.deleteByID(recordId);

            }
        }));
    }

    public void updateRecord(final Record record){
        PainRecordDatabase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                recordDAO.updateRecord(record);
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public CompletableFuture<Record> findByIdFuture(final int recordId) {
        return CompletableFuture.supplyAsync(new Supplier<Record>() {
            @Override
            public Record get() {
                return recordDAO.findByID(recordId);
            }
        } , PainRecordDatabase.databaseWriteExecutor);
    }

    // find by ID
    @RequiresApi(api = Build.VERSION_CODES.N)
    public CompletableFuture<Record> findByID (final int recordId){
        return CompletableFuture.supplyAsync(new Supplier<Record>() {
            @Override
            public Record get() {
                return recordDAO.findByID(recordId);
            }
        },PainRecordDatabase.databaseWriteExecutor);
    }
}
